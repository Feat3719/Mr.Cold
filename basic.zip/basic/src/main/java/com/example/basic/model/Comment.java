package com.example.basic.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.Data;

@Entity
@Data
public class Comment {
    
    @Id 
    @GeneratedValue
    int id;
    String content;
    String writer;

    Date createdDate;
    Date modifiedDate;

    @ManyToOne Board board; //조인 컬럼 어노테이션으로 이름을 설정할 수 있음

}
