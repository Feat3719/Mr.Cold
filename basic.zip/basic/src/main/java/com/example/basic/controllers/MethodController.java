package com.example.basic.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MethodController {
    @GetMapping("req/get")
    @ResponseBody
    public String get(){
        return "get";
    }
    
      @PostMapping("req/post")
      @ResponseBody

    public String post(){
        return "post";
    }
    
}
