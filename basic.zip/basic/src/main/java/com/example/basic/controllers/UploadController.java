package com.example.basic.controllers;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.basic.model.Board;
import com.example.basic.model.FileAtch;
import com.example.basic.model.FileInfo;
import com.example.basic.repository.FileAtchRepository;

@Controller
public class UploadController {

    @Autowired
    FileAtchRepository fileAtchRepository;

    @GetMapping("upload1")
    public String upload1() {
        return "html/upload1";
    }

    @PostMapping("/upload1")
    @ResponseBody
    public String uploadPost(MultipartHttpServletRequest mRequest) {
        MultipartFile mFile = mRequest.getFile("file");
        String fileName = mFile.getOriginalFilename();
        long fileSize = mFile.getSize();

        File folder = new File("c:/files");
        folder.mkdirs();
        File file = new File("c:/files/" + fileName);
        try {
            mFile.transferTo(file);// 파일 저장 해라!
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "[ " + fileName + " ] 파일의 크기는 [ " + fileSize + " byte ] 이네요?";

    }

    @PostMapping("/upload2")
    @ResponseBody
    public String upload2(@RequestParam("file") MultipartFile mFile) {
        String result = "";
        String oName = mFile.getOriginalFilename();
        result += oName + "<br>" + mFile.getSize();

        // 1) 중복 파일이 존재하는지 확인하기
        File file = new File("c:/files/" + oName);
        boolean isFile = file.isFile();
        String sName = oName;
        // 2) 중복파일이 있다면 파일명을 변경하기
        if (isFile) {

            String name = oName.substring(0, oName.indexOf("."));
            String ext = oName.substring(oName.indexOf("."));
            sName = name + System.currentTimeMillis() + ext;
            result += sName + "<br>" + mFile.getSize();
        }

        try {
            mFile.transferTo(new File("c:/files/" + sName));
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        FileAtch fileAtch = new FileAtch();
        fileAtch.setOriginalName(oName);
        fileAtch.setSaveName(sName);
        Board board = new Board();
        board.setId(171);
        fileAtch.setBoard(board);
        fileAtchRepository.save(fileAtch);

        return result;
    }

    @PostMapping("/upload3")
    @ResponseBody
    public String upload3Post(@ModelAttribute FileInfo info) {
        String result = "";
        String oName = info.getFile().getOriginalFilename();
        result += oName + "<br>" + info.getFile().getSize();
        return result;
    }

    @PostMapping("/upload4")
    @ResponseBody
    public String upload4Post(
            @RequestParam("file") MultipartFile[] mFiles) {
        String result = "";

        for (MultipartFile mFile : mFiles) {
            String oName = mFile.getOriginalFilename();
            result += oName + " : " + mFile.getSize() + "<br>";
        }
        return result;
    }

    @GetMapping("/upload6")
    public String upload6() {
        return "html/upload6";
    }

    @PostMapping("/upload6")
    @ResponseBody
    public String upload6Post(MultipartHttpServletRequest mRequest) {
        String result = "";
        Iterator<String> fileNames = mRequest.getFileNames();
        while (fileNames.hasNext()) {
            String fileName = fileNames.next();
            List<MultipartFile> mFiles = mRequest.getFiles(fileName);
            for (MultipartFile mFile : mFiles) {
                String oName = mFile.getOriginalFilename();
                long size = mFile.getSize();
                result += oName + " : " + size + "<br>";
            }
        }
        return result;
    }

}
