package com.example.basic.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.ToString;

@Entity()
@Data()
@ToString(exclude = {"dept"})
public class Emp {
    
    @Id
    Integer empno;
    String ename;
    String job;
    Integer mgr;
    String hiredate;
    Integer sal;
    Integer comm;

      @ManyToOne
    @JoinColumn(name = "deptno")
     Dept dept;
    


   




}
