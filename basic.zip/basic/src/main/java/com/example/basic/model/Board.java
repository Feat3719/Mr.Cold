package com.example.basic.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
// @EqualsAndHashCode(callSuper = false)
public class Board extends BaseTimeEntity {
    @Id @GeneratedValue
    int id;
    String userId;
    String title;
    String content;


    @OneToMany(mappedBy = "board", cascade = CascadeType.ALL)
    List<Comment> comments = new ArrayList<>();


    @OneToMany(mappedBy = "board", cascade = CascadeType.ALL)
    List<FileAtch>fileAtchs = new ArrayList<>();
    
}
