package com.example.basic.controllers;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.basic.model.Dept;
import com.example.basic.model.Owner;
import com.example.basic.repository.OwnerRepository;
import com.example.basic.utill.Encrypt;


@Controller
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    HttpSession session;

    @Autowired
    OwnerRepository ownerRepository;

    @Autowired
    Encrypt encrypt;
    // @GetMapping("/login")
    // public String login(){
      
    
    //     return "auth/login2";
    // }
@GetMapping("/id-check")
@ResponseBody
public String idCheck(@ModelAttribute Owner owner){
    if (owner.getId()==null){
        return "가입불가";
    }

    int id = owner.getId();
    Optional<Owner> opt =  ownerRepository.findById(id);
    if(opt.isPresent()){ // 값 있음, 이미 아이디가 쓰이고 있음, 가입불가
        return "가입불가";
    }else{ // 값 없음 ,아이디가 없음 , 가입가능
        return "가입가능";

    }

}
@Autowired
PasswordEncoder passwordEncoder;

@GetMapping("/signIn")
    public String signIn() throws NoSuchAlgorithmException{
        // String raw = "password1234";
        // String rawAndSalt = "abcd1234";
        // MessageDigest md = MessageDigest.getInstance("SHA-256");
        // md.update(raw.getBytes());
        // String hex = String.format("%064x", new BigInteger(1, md.digest()));
        // System.out.println("raw의 해시값 : "+hex);
        // md.update(rawAndSalt.getBytes());
        // hex = String.format("%064x", new BigInteger(1, md.digest()));
        // System.out.println("raw+salt의 해시값 : "+hex);
        // String pwd =  passwordEncoder.encode("1"); // 암호화한다
        // System.out.println(pwd); //프린트 해보고

        // String rawPwd = "1";
        // String encodedPwd =
        // "$2a$10$c6g3sVHmpxjFVh5HgAN1le5JYzwFEoR2HDDlke7pLnY0xDHxh2Xjy";
        // boolean isMatch = passwordEncoder.matches(rawPwd, encodedPwd); //내가 입력한 값과 대조
        // System.out.println(isMatch);

        String pwd = "1";
        System.out.println(encrypt.encode(pwd));

        return "auth/signin";
    }

    @PostMapping("/signIn")
    public String signInPost(@ModelAttribute Owner owner) {
    
        // int id = owner.getId();
        // System.out.println(id);
        if (owner.getId()==null){ 
             return "redirect:/auth/signIn";
        }
        Optional<Owner> result = ownerRepository.findById(owner.getId());
        if (result.isPresent()){
            
        String pwd = result.get().getPwd();
   // String name = owner.getName();
    //    Owner result = ownerRepository.findByIdAndName(id, name);
// System.out.println(passwordEncoder.matches(owner.getPwd(), pwd));
       if (passwordEncoder.matches(owner.getPwd(), pwd)){
        session.setAttribute("id", owner.getId());
        session.setAttribute("name", result.get().getName());
        return "/html/home";
       }
       }
        return "redirect:/auth/signIn";
    }

    @GetMapping("signUp")
    public String signUp(){
        return "auth/signup";
    }

    @PostMapping("signUp")
    public String signUpPost(@ModelAttribute Owner owner){
        
        // System.out.println("id:"+owner.getId());
        if(owner.getId()!=null || owner.getName()!=null){
        // System.out.println(owner);


String newPwd = passwordEncoder.encode(owner.getPwd());
        owner.setPwd(newPwd);//암호화

        ownerRepository.save(owner);
        return "redirect:/auth/signIn";
        }

        return "redirect:/auth/signUp";
    }


    // @GetMapping("/logout")
    // public String logOut(){
    //     session.removeAttribute("user");
    //     session.removeAttribute("userId");
    //     return  "auth/logout";
    // }




    // @GetMapping("/loginUser")
    // public String login2(@ModelAttribute Owner owner){

    //        if(owner.getId()!=null||owner.getName()!=null){

            // List<Owner> user2 = ownerRepository.findByIdAndName(owner.getId(),owner.getName());

            // if (user2.size()>0){
            //     session.setAttribute("userId", user2.get(0).getName());
            //     return "auth/login2";
            // }
        //     else {session.removeAttribute("userId");
        //         //  return "redirect:/auth/loginUser";
        //         return "/auth/logout";
        //       }
        //    }
                
        //    return "auth/islogin";

    // }
    

    // @GetMapping("/ownerLogin")
    // @ResponseBody
    // public List<Owner> owerLogin(@RequestParam(required = false) int id,
    
    //                         @RequestParam(required = false) String name
                            
    //                         // @RequestParam(required =false) Map<String, String> map 맵형태로 받을 경우
    //                         ){
    //                            List<Owner> owner = ownerRepository.findByIdAndName(id,name);

    //                             return owner;
                            // }
}
