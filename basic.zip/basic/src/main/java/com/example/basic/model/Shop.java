package com.example.basic.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Shop {
    

    @Id
    @GeneratedValue
    int shopId;
    String shopName;
    String shopDesc;
    String restDate;
    String ParkingInfo;
    String imgPath;

}
