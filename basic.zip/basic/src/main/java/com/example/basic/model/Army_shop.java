package com.example.basic.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Army_shop {
    

    @Id
    @GeneratedValue
    int id;
    int year;
    int month;
    String type;
    String name;

}
