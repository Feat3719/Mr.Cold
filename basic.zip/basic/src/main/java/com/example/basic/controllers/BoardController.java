package com.example.basic.controllers;


import java.util.Date;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.basic.model.Board;
import com.example.basic.model.Comment;
import com.example.basic.model.FileAtch;
import com.example.basic.repository.BoardRepository;
import com.example.basic.repository.CommentRepository;
import com.example.basic.repository.FileAtchRepository;

@Controller
@RequestMapping("/board")
public class BoardController {

    @Autowired BoardRepository boardRepository;
@Autowired HttpSession session;

@Autowired CommentRepository commentRepository;
@Autowired FileAtchRepository fileAtchRepository;

    @GetMapping("/remove")
    public String remove(@RequestParam int id){

        String loggedName = (String)session.getAttribute("name");
         Optional<Board> opt = boardRepository.findById(id);
        String saveName = opt.get().getUserId();

        if (saveName.equals(loggedName)){

            Board board = new Board();
                    board.setId(id);
                    // boardRepository.delete(board);
                    boardRepository.deleteById(id);

                return "redirect:/board/list";

        }else{
           return "redirect:/board/list/detail?id="+id;
        }

       
    }

    @GetMapping("/update")
    public String modify(@RequestParam int id, Model model){
 Optional<Board> opt = boardRepository.findById(id);
        model.addAttribute("board", opt.get());
        // if (session.getAttribute("name")==id){
        //     fl
        // }
        return "board/update";
    }

     @PostMapping("/update")
    public String modify(@ModelAttribute Board board){
        System.out.println(board.getId());
        System.out.println(board.getTitle());
        System.out.println(board.getContent());
        
     
        Board board2 = boardRepository.findById(board.getId()).orElse(null);
        System.out.println(board2);
        if (board2 != null) {
            // 엔터티 수정
            board2.setTitle(board.getTitle());
            board2.setContent(board.getContent());
            // ...
        }
        boardRepository.save(board2);
        return "redirect:/board/list";
     
    }



    @GetMapping("/list/detail")
    public String detail(@RequestParam int id, Model model){
        Optional<Board> opt = boardRepository.findById(id);
        model.addAttribute("board", opt.get());
        return "board/detail";
    }

    @GetMapping({"/list","/"}) //주소 두개 사용가능
    public String list(Model model,
    @RequestParam(defaultValue = "1") int p){
        // Direction dic = Direction.DESC;
        Sort sort = Sort.by(Direction.DESC,"id");

         Pageable page = PageRequest.of(p-1, 10,sort );//기본 페이지는 1페이지지만 페이저블은 0이 처음페이지라서
        Page<Board> BoardList = boardRepository.findAll(page);
        model.addAttribute("boardList", BoardList.getContent()); //getContent가 정석인데 없어도 무방
              return "board/list";
    }


    @GetMapping("/write")
    public String write(){


        String name = (String)session.getAttribute("name");

        if (name==null || name.trim().equals("")){
            return "redirect:/auth/signIn";
        }
        return "board/write";
    }


    @PostMapping("/write")
    @Transactional(  rollbackFor = {Exception.class}    )
    public String writePost(@ModelAttribute Board board,
    @RequestParam("file") MultipartFile mFile){
        String originalFilename= mFile.getOriginalFilename();
        System.out.println(originalFilename);
        // Date today = new Date();
        // SimpleDateFormat date = new SimpleDateFormat("yyyy/MM/dd");
        // board.setCreatedDate(today);
        // board.setModifiedDate(LocalDateTime.now());
        Board saveboard = boardRepository.save(board); // 게시글 저장 후 번호 획득하기 위해
        System.out.println(5/0);
        //파일 정보 저장
        FileAtch fileAtch = new FileAtch();
        fileAtch.setOriginalName(originalFilename);
        fileAtch.setSaveName(originalFilename);
        fileAtch.setBoard(saveboard);
        fileAtchRepository.save(fileAtch);

        return "redirect:/board/write";
    }
    


    @PostMapping("/comment")
    public String comment (@ModelAttribute Comment comment,
                            @RequestParam int boardId){
        String name = (String) session.getAttribute("name");
        if (name==null){
            name = "익명";
        }
        comment.setWriter(name);
        System.out.println(new Date());
        comment.setCreatedDate( new Date());

        Board board = new Board();
        board.setId(boardId);
        comment.setBoard(board);//jpa는 객체로 가지고 있어야 해서 만들어서 넣는다.
        commentRepository.save(comment);
        return "redirect:/board/list";
    }


    @GetMapping("/comment/remove")
    public String commentRemove(@ModelAttribute Comment comment, int boardId){
        // Comment comment = new Comment();
        // comment.setId(id);
        commentRepository.delete(comment);
        return "redirect:/board/list/detail?id="+boardId;
    }

}
