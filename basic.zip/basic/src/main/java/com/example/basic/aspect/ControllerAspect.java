package com.example.basic.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
public class ControllerAspect {
    long start=0L;
    long end=0L;
    @Before(value = "execution (* com.example.basic.controllers.*.*(..))")//(..)매개변수 유무 상관없음
    public void onBeforeHandler(JoinPoint joinPoint) {
    log.warn("@Before run");
    start = System.currentTimeMillis();
    }
  
    @AfterReturning(value = "execution (* com.example.basic.utill.*.*(..))",
    returning = "data")
    public void onAfterReturningHandler(JoinPoint joinPoint, Object data) {
    if (data != null) {
    log.warn("uuuuuuuuuuuuu"+data.toString());
    }
    log.debug("@AfterReturning run");
}

   @AfterReturning(value = "execution (* com.example.basic.utill.*.*(..))",
    returning = "data")
    public void amugona (JoinPoint joinPoint) {
    String name = joinPoint.getSignature().getName();
    log.warn( "이름은?"+name);
    


}


    @AfterThrowing(value = "execution (* com.example.basic.controllers.AuthController.*.*(..))")
    public void afterThrowing(JoinPoint joinPoint){
        log.warn("오류 발생");
    }

}
