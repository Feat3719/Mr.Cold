package com.example.basic.controllers;

import java.security.Provider.Service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.batch.BatchProperties.Jdbc;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.basic.model.Army_shop;
import com.example.basic.model.Dept;
import com.example.basic.model.Emp;
import com.example.basic.model.Food;
import com.example.basic.model.Player;
import com.example.basic.model.Shop;
import com.example.basic.repository.ArmyRepository;
import com.example.basic.repository.DeptRepository;
import com.example.basic.repository.EmpRepository;
import com.example.basic.repository.FoodRepository;
import com.example.basic.repository.PlayerRepository;
import com.example.basic.repository.ShopRepository;

import lombok.Data;

@Controller
public class HomeController {

    @Autowired
    EmpRepository empRepository;
    @Autowired
    ArmyRepository armyRepository;

    @Autowired
    ShopRepository shopRepository;

    @Autowired
    PlayerRepository playerRepository;

    @Autowired
    DeptRepository deptRepository;

    @Autowired
    FoodRepository foodRepository;

    // JdbcTemplate jt;

    @RequestMapping(method = RequestMethod.GET, value = "/") // 매핑으로 라고 들어왔을때 처리를 하겠다.
    public String Home(@RequestParam(required = false, defaultValue = "1") Integer page,
            @RequestParam(required = false, defaultValue = "2") String userId,
            @ModelAttribute Phone phone) {
        System.out.println(phone.getPrice());

        return "home"; // 메소드 함수들은 리턴을 해준다. 문자로 리턴할시home.html을 열겠다는 뜻

    }

    @RequestMapping("/json") // 매핑으로 라고 들어왔을때 처리를 하겠다.
    @ResponseBody // 제이슨
    public Map<String, Object> json() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("adf", "안녕하세요");

        return map; // 메소드 함수들은 리턴을 해준다. 문자로 리턴할시 home.html을 열겠다는 뜻
    }

    @RequestMapping("/json/{user}") // 매핑으로 라고 들어왔을때 처리를 하겠다.
    @ResponseBody // 제이슨
    public Map<String, Object> path(
            @PathVariable String user) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("adf", "안녕하세요");
        map.put("user", user);
        return map; // 메소드 함수들은 리턴을 해준다. 문자로 리턴할시 home.html을 열겠다는 뜻
    }

    @RequestMapping("/phone")
    @ResponseBody
    public Phone phone() {
        Phone phone = new Phone();
        phone.setBrand("234");
        phone.setPrice(2131);
        return phone;
    }

    @RequestMapping("html/exam")
    public String asf() {
        return "html/exam";
    }

    @RequestMapping("/json/exam")
    @ResponseBody
    public Map<String, Object> jsonExam() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("count", 2);
        List<Map<String, Object>> list = new ArrayList<>();
        Map<String, Object> map2 = new HashMap<String, Object>();

        map2.put("name", "가");
        map2.put("userId", "map2id");

        list.add(map2);
        map2 = new HashMap<String, Object>();
        map2.put("name2", "가2");
        map2.put("userId", "map2id2");
        list.add(map2);
        map.put("list", list);

        return map;

    }
    // @GetMapping("/req/data")
    // @ResponseBody
    // public List<Map<String, Object>> data(
    // @RequestParam(defaultValue = "서울") String area ,
    // @RequestParam(defaultValue = "0") String score
    // ){
    // // List<Map<String, Object>> list = jt.queryForList("select * from emp");

    // List<Map<String, Object>> list =jt.queryForList("select * from
    // holiday_parking "+
    // "where address like concat('%', ?, '%')", "광주");

    // Map<String,Object> map3 = new HashMap<>();
    // map3.put("area",area);
    // map3.put("score",score);

    // return list;
    // }

    // @RequestMapping("/emp")
    // @ResponseBody
    // public String emp(){
    // Emp emp = new Emp();
    // emp.setEmpno(4);
    // emp.setAge(123);
    // emp.setEname("김남");
    // emp.setJob("검사");

    // empRepository.save(emp);
    // return "입력완료";
    // }

    @RequestMapping("/emp")
    @ResponseBody
    public Emp emp(@ModelAttribute Emp emp) {

        empRepository.save(emp);
        return emp;
    }

    @GetMapping("/empList")
    @ResponseBody
    public List<Emp> empList() {
        List<Emp> list = empRepository.findAll();
        return list;
    }

    @GetMapping("/armyList")
    @ResponseBody
    public List<Army_shop> armyList() {
        List<Army_shop> list = armyRepository.findAll();
        return list;
    }

    @GetMapping("/shopList")
    @ResponseBody
    public List<Shop> shopList() {
        List<Shop> list = shopRepository.findAll();
        return list;
    }

    @GetMapping("/player")
    @ResponseBody
    public List<Player> player() {
        List<Player> list = playerRepository.findAll();
        return list;
    }

    @GetMapping("/emp-all-data")
    @ResponseBody
    public List<Emp> emps() {
        List<Emp> emp = empRepository.findAll();
        return emp;
    }

    @GetMapping("/dept")
    @ResponseBody
    public String dept() {
        Dept dept = new Dept();
        dept.setDeptno(50);
        dept.setDname("ACCOUNTING");
        dept.setLoc("NEWYORK1");
        deptRepository.save(dept);
        return "입력완료";
    }

    @GetMapping("/deptList")
    @ResponseBody
    public List<Dept> deptList() {
        List<Dept> detps = deptRepository.findAll();
        return detps;
    }

    @GetMapping("/pagination")
    @ResponseBody
    public List<Emp> pagination() {
        Sort sort = Sort.by("ename");
        Pageable page = PageRequest.of(1, 5, sort);
        Page<Emp> list = empRepository.findAll(page);
        System.out.println(list.getTotalPages());
        return list.getContent();
    }

    // @GetMapping("/foodpagination")
    // @ResponseBody
    // public List<Food> foodpagination(){
    // Sort sort = Sort.by(Sort.Direction.DESC,"id");

    // Pageable page = PageRequest.of(1, 10 , sort );
    // Page<Food> list = foodRepository.findAll(page);
    // System.out.println(list.getTotalPages());
    // return list.getContent();
    // }

    @GetMapping("/foodpagination")
    @ResponseBody
    public List<Food> foodpagination(@RequestParam(defaultValue = "1") int p) {
        Sort sort = Sort.by(Sort.Direction.DESC, "id");
        Pageable page = PageRequest.of(p - 1, 10, sort);
        Page<Food> list = foodRepository.findAll(page);
        System.out.println(list.getTotalPages());
        return list.getContent();
    }

    @GetMapping("pagination2")
    public String pagination(
            Model model, @RequestParam(defaultValue = "1") int page) {
        
        int maxPage = 34;
        
        if (page>maxPage){page=maxPage;}
        if (page<1){page=1;}

        int startPage = (page - 1) / 10 * 10 + 1;
        int endPage = startPage+10>maxPage?maxPage:startPage + 9;
        model.addAttribute("startPage", startPage);
        model.addAttribute("endPage", endPage);
        model.addAttribute("page", page);
        model.addAttribute("maxPage", maxPage);
        return "pagination";
    }



 
}

@Data
class Phone {
    int price;
    String brand;

}