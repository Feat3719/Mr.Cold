package com.example.basic;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;

import com.example.basic.model.Dept;
import com.example.basic.model.Emp;
import com.example.basic.model.Food;
import com.example.basic.model.Owner;
import com.example.basic.model.Product;
import com.example.basic.repository.DeptRepository;
import com.example.basic.repository.EmpRepository;
import com.example.basic.repository.FoodRepository;
import com.example.basic.repository.OwnerRepository;
import com.example.basic.repository.ProductRepository;
@SpringBootTest
class BasicApplicationTests {

	@Autowired
	DeptRepository deptRepository;

	@Autowired
	EmpRepository empRepository;
	
	@Autowired
	FoodRepository foodRepository;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	OwnerRepository ownerRepository;

	@Test
	void contextLoads() {
	List<Emp> list =	empRepository.findAll();
	System.out.println(list);


	}

	@Test @Transactional
	void contextLoads2() {
	List<Dept> list =	deptRepository.findAll();
	System.out.println(list);

}


@Test
	void emp테이블의jobm으로조회하기() {
	List<Emp> list =	empRepository.findByJob("MANAGER");
	list= empRepository.findBySalGreaterThanEqual(2000); 
	list = empRepository.findByEnameEquals("JONES");
	System.out.println(list);


	}
@Test
	void empsdfasdf() {
			Sort sort = Sort.by(Sort.Direction.DESC,"id");

	Pageable page = PageRequest.of(1, 10 , sort );
	Page<Food> list = foodRepository.findAll(page);
	System.out.println(list.getTotalPages());
        
}


@Test
	void add() {
		Optional<Product> opt =  productRepository.findById(1);
		Product product = opt.get();
		System.out.println(product);
        
}

@Test
@Transactional
	void ad2d() {
		Optional<Owner> opt =  ownerRepository.findById(1);
		Owner owner = opt.get();
		System.out.println(owner);
        
}
}